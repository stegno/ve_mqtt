from asyncio_vedirect_mqtt.mqtt import AsyncIOVeDirectMqtt
from importlib.metadata import version
__version__ = version(__package__)
